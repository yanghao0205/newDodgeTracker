# DodgeTracker

## How to install
- Download and install [Pengu Loader](https://github.com/PenguLoader/PenguLoader) (Version >= 1.1.0)
- Download the dodge-tracker.js on release page and put it in **plugins** folder

## How to add players to dodge list?
- Open league settings
- Search for the Dodge Tracker tab
- Write the player Name#TAG and press enter

- Or just right click user in post game or match history

## Showcase
<p>
<img align="right" src="https://media.discordapp.net/attachments/1189693072548839464/1189971956108378202/image.png?ex=65a01abe&is=658da5be&hm=8582c21641864b9810fc82aed3c332e48ab90cc48c055bb9ff262b650e067ae8&=&format=webp&quality=lossless&width=991&height=671" alt="image" />
<img src="https://media.discordapp.net/attachments/1189693072548839464/1189693073198940231/image.png?ex=659f1704&is=658ca204&hm=92b6301599881d938f9965d399dcbfc20ce94d6a2ebdc2438b38fc11cdfc8502&=&format=webp&quality=lossless" alt="image" />
<img src="https://media.discordapp.net/attachments/1189693072548839464/1189693073538695249/image.png?ex=659f1704&is=658ca204&hm=7f9ed76b958a56d2ac71f6a8eb8d4f096573adb0817e8d52e24fd7b845ab87e1&=&format=webp&quality=lossless" alt="image" />
<img src="https://media.discordapp.net/attachments/862669234457542656/1190436559565095013/image.png?ex=65a1cb71&is=658f5671&hm=ec3d380f5024212365e6858e1a5d13883d43ce41bf7d15ab2acd67fa18bddf9e&=&format=webp&quality=lossless" alt="image" />
</p>

## Credits
- [Seiku](https://github.com/vergonha) - First Version 
- @unproductive - post game and match history menu button
